var size = {
    width: window.innerWidth,
    height: window.innerHeight
};

var returnValue = JSON.stringify(size);

// this will be returned as parameter in callback
returnValue;
